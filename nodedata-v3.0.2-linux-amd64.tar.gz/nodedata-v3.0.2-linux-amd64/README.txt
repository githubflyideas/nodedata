nodedata — 部署说明

1) 放置
   把 nodedata 与你的 index.html 放在同一目录，例如 /opt/nodedata/：
     /opt/nodedata/nodedata
     /opt/nodedata/index.html

2) 启动
     cd /opt/nodedata && ./nodedata serve --port 8888

   若无法保证工作目录，显式指定（推荐用于 systemd）：
     ./nodedata serve --port 8888 --web-root /opt/nodedata --data-dir /var/lib/nodedata

3) 参数
   --port           监听端口，默认 8888
   --interval       采集与 L0 检查间隔，默认 5s
   --dump-interval  data/*.json 落盘间隔，默认 30s
   --web-root       index.html 所在目录，默认 cwd（cwd 无 index.html 时回退到可执行文件目录）
   --data-dir       转储目录，默认 <web-root>/data
   --proc           procfs 根，默认 /proc

4) 端点
   /                    静态页面
   /data/{1h,6h,24h,7d,30d}.json   转储；磁盘文件缺失时自动改为内存实时生成
   /data/health.json    采集器自监控
   /api/check           L0 39 项判断
   /api/diagnosis[?z=3] L4 诊断链
   /api/heatmap?from=&to=
   /api/raw?metric=&from=&to=

5) 关于 z 值为 null
   十四档偏离度需要对应长度的历史。刚启动时 L5(5400s) 以上各档 σ 未就绪，
   z 返回 null、breadth 为 0，这是正常的。跑满对应时长后自动出值。
   进程内缓冲保留约 24 小时（5s 间隔），重启后需重新积累。

6) 单次检查（不起服务）
     ./nodedata check
   退出码：0 全部通过，1 有失败项，2 仅有告警。

注意：包内不含 index.html，避免覆盖你现有的页面。
